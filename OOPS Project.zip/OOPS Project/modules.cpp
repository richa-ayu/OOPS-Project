#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct Student {
    string name;
    int roll_no;
    int math_score;
    int english_score;
    int science_score;
};

vector<Student> students;

void displayRecords() {
    cout << "---------------------------------------------" << endl;
    cout << "Roll no\tName\t\tMath\tEng\tScience" << endl;
    cout << "---------------------------------------------" << endl;

    for (const auto& s : students) {
        cout << s.roll_no << "\t" << s.name << "\t" << s.math_score << "\t" << s.english_score << "\t" << s.science_score <<  endl;
    }
}

void displayData(){
    int roll;
    cout << "Enter Roll no of student: ";
    cin >> roll;

    for (auto& s : students) {
        if (s.roll_no == roll) {
            cout << "Roll number: " << s.roll_no << endl;
            cout << "Student Name: " << s.name << endl;
            cout << "Math Score: " << s.math_score << endl;
            cout << "English Score: " << s.english_score << endl;
            cout << "Science Score: " << s.science_score << endl;
            break;
        }
        else{
            cout << "Data not Found!!";
        }
    }
}

void modifyRecord() {
    int roll;
    cout << "Enter Roll no of student to modify: ";
    cin >> roll;

    for (auto& s : students) {
        if (s.roll_no == roll) {
            cout << "Enter new math score: ";
            cin >> s.math_score;
            cout << "Enter new english score: ";
            cin >> s.english_score;
            cout << "Enter new science score: ";
            cin >> s.science_score;
            break;
        }
        else{
            cout << "Data not Found!!";
        }
    }
}

void editRecord() {
    int roll;
    cout << "Enter Roll no of student to edit: ";
    cin >> roll;

    for (auto& s : students) {
        if (s.roll_no == roll) {
            cout << "Enter new name: ";
            getline(cin >> ws, s.name);
            break;
        }
        else{
            cout << "Data not Found!!";
        }
    }
}

void addRecord() {
    Student s;
    cout << "Enter Roll no of new student: ";
    cin >> s.roll_no;
    cout << "Enter name of new student: ";
    getline(cin >> ws, s.name);
    cout << "Enter math score: ";
    cin >> s.math_score;
    cout << "Enter english score: ";
    cin >> s.english_score;
    cout << "Enter science score: ";
    cin >> s.science_score;
    students.push_back(s);
       
}

void deleteRecord() {
    int roll;
    cout << "Enter ROll no of student to delete: ";
    cin >> roll;

    for (auto it = students.begin(); it != students.end(); ++it) {
        if (it->roll_no == roll) {
            students.erase(it);
            cout << "Data Removed";
            break;
        }
    }
}
