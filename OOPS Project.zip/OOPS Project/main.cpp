#include <iostream>
#include "modules.cpp"

using namespace std;

int main() {
    int choice = -1;

    while (choice != 0) {
        cout << endl;
        cout << "1. Display student records" << endl;
        cout << "2. Display student report" << endl;
        cout << "3. Add a new student record" << endl;
        cout << "4. Modify a student record" << endl;
        cout << "5. Edit a student record" << endl;
        cout << "6. Delete a student record" << endl;
        cout << "0. Quit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                displayRecords();
                break;
            case 2:
                displayData();
                break;
            case 3:
                addRecord();
                break;
            case 4:
                modifyRecord();
                break;
            case 5:
                editRecord();
                break;
            case 6:
                deleteRecord();
                break;
            case 0:
                cout << "Exiting program..." << endl;
                break;
            default:
                cout << "Invalid choice, try again." << endl;
        }
    }

    return 0;
}
